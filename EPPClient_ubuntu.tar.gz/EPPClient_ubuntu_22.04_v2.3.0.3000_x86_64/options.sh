#!/usr/bin/env sh
## uncomment and modify the values that you need to set for your specific configuration

EPPCLIENT_WS_SERVER=ep.multicaja.cl
export EPPCLIENT_WS_SERVER

EPPCLIENT_WS_PORT=2053
export EPPCLIENT_WS_PORT

#EPPCLIENT_DEPARTMENT_CODE=defdep
#export EPPCLIENT_DEPARTMENT_CODE

## proxy settings should be like this: address:port:user:password
## for a proxy without authentification (user and password are blank): address:port::
#EPPCLIENT_HTTPS_PROXY=
#export EPPCLIENT_HTTPS_PROXY

#EPPCLIENT_DISABLECAP=
#export EPPCLIENT_DISABLECAP

#EPPCLIENT_SUPPRESSRD=
#export EPPCLIENT_SUPPRESSRD

#EPPCLIENT_COMSEC=0
#export EPPCLIENT_COMSEC
